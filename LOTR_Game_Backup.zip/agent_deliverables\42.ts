```typescript
function isPowerOfTwo(n: number): boolean {
    return n > 0 && (n & (n - 1)) === 0;
}

// Example usage:
console.log(isPowerOfTwo(8));   // true
console.log(isPowerOfTwo(10));  // false
```