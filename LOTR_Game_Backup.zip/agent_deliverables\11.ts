```typescript
function sumEvenNumbers(arr: number[]): number {
    return arr.filter(num => num % 2 === 0).reduce((a, b) => a + b, 0);
}

// Example usage:
const numbers = [1, 2, 3, 4, 5, 6];
console.log(sumEvenNumbers(numbers)); // Output: 12
```