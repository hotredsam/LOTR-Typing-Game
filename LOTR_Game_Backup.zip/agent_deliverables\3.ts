```typescript
function isPrime(n: number): boolean {
    if (n <= 1) return false;
    for (let i = 2; i * i <= n; i++) {
        if (n % i === 0) return false;
    }
    return true;
}

// Example usage:
const num = 23;
console.log(`${num} is prime: ${isPrime(num)}`);
```