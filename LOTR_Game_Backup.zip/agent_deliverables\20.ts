```typescript
function calculateFactorial(n: number): number {
    if (n < 0) {
        throw new Error("Input must be a non-negative integer.");
    } else if (n === 0 || n === 1) {
        return 1;
    } else {
        let result = 1;
        for (let i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }
}

// Example usage:
console.log(calculateFactorial(5)); // Output: 120
```