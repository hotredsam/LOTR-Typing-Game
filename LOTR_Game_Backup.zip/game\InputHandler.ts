/**
 * Handles keyboard input for the typing game.
 */
export class InputHandler {
  private callback: (char: string) => void;
  private onKeyDownBound: (event: KeyboardEvent) => void;

  constructor(callback: (char: string) => void) {
    this.callback = callback;
    this.onKeyDownBound = this.onKeyDown.bind(this);
    window.addEventListener('keydown', this.onKeyDownBound);
  }

  private onKeyDown(event: KeyboardEvent): void {
    // Only capture single characters (printable)
    if (event.key.length === 1) {
      this.callback(event.key);
    }
  }

  public cleanup(): void {
    window.removeEventListener('keydown', this.onKeyDownBound);
  }
}
