```typescript
function isPerfectSquare(n: number): boolean {
    if (n < 0) return false;
    let i = 0;
    while (i * i <= n) {
        if (i * i === n) return true;
        i++;
    }
    return false;
}

// Example usage:
console.log(isPerfectSquare(25)); // Output: true
console.log(isPerfectSquare(24)); // Output: false
```