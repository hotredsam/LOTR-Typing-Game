import { create } from 'zustand';
import { IGameState, IWord } from '../types/game';

interface GameActions {
  addWord: (word: IWord) => void;
  removeWord: (id: string) => void;
  updateScore: (points: number) => void;
  setStats: (wpm: number, accuracy: number) => void;
  setGameOver: (isGameOver: boolean) => void;
  resetGame: () => void;
}

export const useGameStore = create<IGameState & GameActions>((set) => ({
  score: 0,
  wpm: 0,
  accuracy: 0,
  activeWords: [],
  level: 1,
  isGameOver: false,

  addWord: (word) =>
    set((state) => ({ activeWords: [...state.activeWords, word] })),

  removeWord: (id) =>
    set((state) => ({
      activeWords: state.activeWords.filter((w) => w.id !== id),
    })),

  updateScore: (points) =>
    set((state) => ({ score: state.score + points })),

  setStats: (wpm, accuracy) =>
    set(() => ({ wpm, accuracy })),

  setGameOver: (isGameOver) =>
    set(() => ({ isGameOver })),

  resetGame: () =>
    set({
      score: 0,
      wpm: 0,
      accuracy: 0,
      activeWords: [],
      level: 1,
      isGameOver: false,
    }),
}));
