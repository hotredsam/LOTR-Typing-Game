import React, { useEffect, useRef } from 'react';
import Phaser from 'phaser';
import MainScene from './game/MainScene';
import HUD from './components/HUD';
import GameOver from './components/GameOver';

const App: React.FC = () => {
  const gameRef = useRef<Phaser.Game | null>(null);

  useEffect(() => {
    if (!gameRef.current) {
      const config: Phaser.Types.Core.GameConfig = {
        type: Phaser.AUTO,
        parent: 'game-container',
        width: 800,
        height: 600,
        scene: [MainScene],
        physics: {
          default: 'arcade',
          arcade: {
            debug: false,
          },
        },
      };

      gameRef.current = new Phaser.Game(config);
    }

    return () => {
      if (gameRef.current) {
        gameRef.current.destroy(true);
        gameRef.current = null;
      }
    };
  }, []);

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', backgroundColor: '#111' }}>
      <div style={{ position: 'relative', width: '800px', height: '600px' }}>
        <div id="game-container" />
        <HUD />
        <GameOver />
      </div>
    </div>
  );
};

export default App;
