```typescript
function sieveOfEratosthenes(limit: number): number[] {
  const isPrime = new Array(limit + 1).fill(true);
  isPrime[0] = isPrime[1] = false;

  for (let i = 2; i * i <= limit; i++) {
    if (isPrime[i]) {
      for (let j = i * i; j <= limit; j += i) {
        isPrime[j] = false;
      }
    }
  }

  return isPrime.reduce((primes, isPrime, num) => isPrime && num > 1 ? [...primes, num] : primes, []);
}

// Example usage:
const limit = 50;
console.log(sieveOfEratosthenes(limit));
```