import React from 'react';
import { useGameStore } from '../stores/useGameStore';

const GameOver: React.FC = () => {
  const isGameOver = useGameStore((state) => state.isGameOver);
  const score = useGameStore((state) => state.score);
  const resetGame = useGameStore((state) => state.resetGame);

  if (!isGameOver) return null;

  const overlayStyle: React.CSSProperties = {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
    color: '#fff',
    fontFamily: "'Cinzel', serif",
  };

  const modalStyle: React.CSSProperties = {
    padding: '40px',
    borderRadius: '10px',
    border: '2px solid #ffd700',
    backgroundColor: '#1a1a2e',
    textAlign: 'center',
    boxShadow: '0 0 20px rgba(255, 215, 0, 0.3)',
  };

  const buttonStyle: React.CSSProperties = {
    marginTop: '20px',
    padding: '10px 30px',
    fontSize: '18px',
    backgroundColor: '#ffd700',
    color: '#1a1a2e',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontWeight: 'bold',
    transition: 'transform 0.2s',
  };

  return (
    <div style={overlayStyle}>
      <div style={modalStyle}>
        <h1 style={{ fontSize: '48px', color: '#ff4d4d', margin: '0 0 20px 0' }}>GAME OVER</h1>
        <p style={{ fontSize: '24px' }}>Final Score: {score}</p>
        <button 
          style={buttonStyle}
          onClick={() => resetGame()}
          onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
          onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1.0)'}
        >
          RESTART MISSION
        </button>
      </div>
    </div>
  );
};

export default GameOver;
