```typescript
class Node {
    data: any;
    next: Node | null;

    constructor(data: any) {
        this.data = data;
        this.next = null;
    }
}

class Queue {
    front: Node | null;
    rear: Node | null;

    constructor() {
        this.front = null;
        this.rear = null;
    }

    isEmpty(): boolean {
        return this.front === null;
    }

    enqueue(data: any): void {
        const newNode = new Node(data);
        if (this.rear === null) {
            this.front = newNode;
            this.rear = newNode;
        } else {
            this.rear.next = newNode;
            this.rear = newNode;
        }
    }

    dequeue(): any {
        if (this.isEmpty()) {
            throw new Error("Queue is empty");
        }
        const data = this.front.data;
        this.front = this.front.next;
        if (this.front === null) {
            this.rear = null;
        }
        return data;
    }

    peek(): any {
        if (this.isEmpty()) {
            throw new Error("Queue is empty");
        }
        return this.front.data;
    }

    size(): number {
        let count = 0;
        let temp = this.front;
        while (temp !== null) {
            count++;
            temp = temp.next;
        }
        return count;
    }
}

// Example usage:
const queue = new Queue();
queue.enqueue(1);
queue.enqueue(2);
queue.enqueue(3);

console.log(queue.dequeue()); // Output: 1
console.log(queue.peek()); // Output: 2
console.log(queue.size()); // Output: 2

```