```typescript
function calculatePower(base: number, exponent: number): number {
    if (exponent === 0) return 1;
    if (exponent < 0) return 1 / calculatePower(base, -exponent);
    if (exponent % 2 === 0) return Math.pow(base, exponent / 2) * calculatePower(base, exponent / 2);
    return base * calculatePower(base, exponent - 1);
}

// Example usage:
console.log(calculatePower(2, 3)); // Output: 8
```