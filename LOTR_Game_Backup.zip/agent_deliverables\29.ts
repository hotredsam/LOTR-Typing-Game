```typescript
class Graph {
    private adjacencyList: Map<number, { [key: number]: number }>;
    private V: number;

    constructor(vertices: number) {
        this.V = vertices;
        this.adjacencyList = new Map();
        for (let i = 0; i < vertices; i++) {
            this.adjacencyList.set(i, {});
        }
    }

    addEdge(u: number, v: number, weight: number): void {
        if (!this.adjacencyList.has(u)) {
            throw new Error(`Vertex ${u} does not exist in the graph`);
        }
        if (!this.adjacencyList.has(v)) {
            throw new Error(`Vertex ${v} does not exist in the graph`);
        }

        this.adjacencyList.get(u)[v] = weight;
    }

    dijkstra(start: number): { [key: number]: number } {
        const distance: { [key: number]: number } = {};
        const visited: Set<number> = new Set();
        for (let i = 0; i < this.V; i++) {
            distance[i] = Infinity;
        }
        distance[start] = 0;

        while (visited.size < this.V) {
            let minDistance = Infinity;
            let minIndex = -1;
            for (const [key, value] of this.adjacencyList) {
                if (!visited.has(key) && value[Object.keys(value)[0]] < minDistance) {
                    minDistance = value[Object.keys(value)[0]];
                    minIndex = key;
                }
            }

            visited.add(minIndex);
            for (const [key, value] of this.adjacencyList.get(minIndex)) {
                const newDistance = distance[minIndex] + value[key];
                if (newDistance < distance[key]) {
                    distance[key] = newDistance;
                }
            }
        }

        return distance;
    }
}

// Example usage
const graph = new Graph(9);
graph.addEdge(0, 1, 4);
graph.addEdge(0, 7, 8);
graph.addEdge(1, 2, 8);
graph.addEdge(1, 7, 11);
graph.addEdge(2, 3, 5);
graph.addEdge(2, 8, 9);
graph.addEdge(2, 5, 1);
graph.addEdge(3, 4, 6);
graph.addEdge(3, 5, 3);
graph.addEdge(4, 5, 2);
graph.addEdge(5, 6, 7);
graph.addEdge(6, 7, 12);
graph.addEdge(6, 8, 10);

console.log(graph.dijkstra(0));
```