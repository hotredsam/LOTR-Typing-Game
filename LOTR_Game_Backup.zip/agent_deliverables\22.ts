```typescript
function isPalindrome(n: number): boolean {
    return n.toString() === n.toString().split('').reverse().join('');
}

// Example usage:
console.log(isPalindrome(121));  // true
console.log(isPalindrome(123));  // false
```