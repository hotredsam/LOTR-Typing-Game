```typescript
function temperatureConverter(value: number, unit: 'C' | 'F'): number {
    if (unit === 'C') {
        return (value * 9/5) + 32;
    } else if (unit === 'F') {
        return (value - 32) * 5/9;
    } else {
        throw new Error('Invalid unit. Please use "C" for Celsius or "F" for Fahrenheit.');
    }
}

// Example usage:
console.log(temperatureConverter(0, 'C')); // Output: 32
console.log(temperatureConverter(32, 'F')); // Output: 0
```