```typescript
// Calculator class
class Calculator {
  private memory: number;

  constructor() {
    this.memory = 0;
  }

  // Addition operation
  add(num1: number): void {
    const result = this.memory + num1;
    console.log(`Result: ${result}`);
    this.memory = result;
  }

  // Subtraction operation
  subtract(num2: number): void {
    const result = this.memory - num2;
    console.log(`Result: ${result}`);
    this.memory = result;
  }

  // Multiplication operation
  multiply(num3: number): void {
    const result = this.memory * num3;
    console.log(`Result: ${result}`);
    this.memory = result;
  }

  // Division operation
  divide(num4: number): void {
    if (num4 !== 0) {
      const result = this.memory / num4;
      console.log(`Result: ${result}`);
      this.memory = result;
    } else {
      console.log("Error! Division by zero is not allowed.");
    }
  }

  // Display current memory value
  displayMemory(): void {
    console.log(`Current Memory Value: ${this.memory}`);
  }
}

// Main function to test the calculator
function main(): void {
  const calculator = new Calculator();

  while (true) {
    console.log("\n1. Addition");
    console.log("2. Subtraction");
    console.log("3. Multiplication");
    console.log("4. Division");
    console.log("5. Display Memory");
    console.log("6. Exit");

    const choice = prompt("Enter your choice (1-6): ");

    switch (choice) {
      case "1":
        calculator.add(Number(prompt("Enter number 1: ")));
        break;
      case "2":
        calculator.subtract(Number(prompt("Enter number 2: ")));
        break;
      case "3":
        calculator.multiply(Number(prompt("Enter number 3: ")));
        break;
      case "4":
        calculator.divide(Number(prompt("Enter number 4: ")));
        break;
      case "5":
        calculator.displayMemory();
        break;
      case "6":
        console.log("Exiting...");
        return;
      default:
        console.log("Invalid choice. Please try again.");
    }
  }
}

main();
```