```typescript
function isValidCreditCard(cardNumber: string): boolean {
    // Remove any non-digit characters from the card number
    const cleanCardNumber = cardNumber.replace(/\D+/g, '');

    // Check if the card number has at least 13 digits and no more than 16 digits
    if (cleanCardNumber.length < 13 || cleanCardNumber.length > 16) {
        return false;
    }

    // Check for valid card number patterns
    const pattern = /^4|5[1-5]|6(?:011|5[0-9]{2})$/;

    // If the card number matches any of these patterns, it's likely a valid credit card number
    if (pattern.test(cleanCardNumber)) {
        return true;
    }

    // Check for Diners Club and Discover card numbers
    const dinersClubPattern = /^3(?:0[0-5]|[68][0-9])[0-9]{11}$/;
    const discoverPattern = /^6(?:011|5[0-9]{2})$/;

    if (dinersClubPattern.test(cleanCardNumber) || discoverPattern.test(cleanCardNumber)) {
        return true;
    }

    // If none of the above patterns match, it's likely not a valid credit card number
    return false;
}

// Example usage:
console.log(isValidCreditCard('4532015112830366'));  // Returns: true
console.log(isValidCreditCard('5105105105105100'));   // Returns: true
console.log(isValidCreditCard('6011514433546201'));   // Returns: true
console.log(isValidCreditCard('6771549495586802'));   // Returns: false
```