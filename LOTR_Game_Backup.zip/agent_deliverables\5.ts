```typescript
function sortArray(arr: number[]): number[] {
    // Create a copy of the original array to avoid modifying it directly
    const arrCopy = [...arr];

    // Use the built-in sort function with a compare function to sort the array
    arrCopy.sort((a, b) => a - b);

    return arrCopy;
}

// Example usage:
const unsortedArray = [64, 34, 25, 12, 22, 11, 90];
console.log("Unsorted Array:", unsortedArray);
const sortedArray = sortArray(unsortedArray);
console.log("Sorted Array:", sortedArray);
```