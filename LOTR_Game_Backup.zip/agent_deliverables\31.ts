```typescript
function quicksort(arr: number[]): number[] {
    if (arr.length <= 1) return arr;
    const pivot = arr[Math.floor(arr.length / 2)];
    const left = arr.filter(x => x > pivot);
    const middle = arr.filter(x => x === pivot);
    const right = arr.filter(x => x < pivot);
    return [...quicksort(left), ...middle, ...quicksort(right)];
}

// Example usage:
const arr = [35, 1, 45, 5, 54, 2, 8, 12];
console.log("Original array:", arr);
console.log("Sorted array in descending order:", quicksort(arr).reverse());
```