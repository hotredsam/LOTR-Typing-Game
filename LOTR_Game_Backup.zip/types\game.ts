/**
 * Data structures for the typing game.
 */

export interface IWord {
  /** Unique identifier for the word. */
  id: string;
  /** The actual text characters. */
  text: string;
  /** Horizontal position. */
  x: number;
  /** Vertical position. */
  y: number;
  /** Movement speed. */
  speed: number;
}

export interface IGameState {
  /** Total score accumulated. */
  score: number;
  /** Current Words Per Minute. */
  wpm: number;
  /** Typing accuracy percentage. */
  accuracy: number;
  /** Words currently active on screen. */
  activeWords: IWord[];
  /** Current difficulty level. */
  level: number;
  /** Game status flag. */
  isGameOver: boolean;
}

export interface IGameConfig {
  /** Initial word movement speed. */
  initialSpeed: number;
  /** Delay between word spawns (ms). */
  spawnRate: number;
  /** Difficulty increase factor. */
  difficultyMultiplier: number;
}
