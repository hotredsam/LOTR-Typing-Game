```typescript
function findLargestAndSmallest(numbers: number[]): [number, number] {
    if (numbers.length === 0) {
        throw new Error("Array is empty");
    }

    const smallest = Math.min(...numbers);
    const largest = Math.max(...numbers);

    return [smallest, largest];
}

// Example usage:
const numbers = [12, 45, 7, 23, 56, 89, 34];
try {
    const [smallest, largest] = findLargestAndSmallest(numbers);
    console.log(`Smallest number: ${smallest}`);
    console.log(`Largest number: ${largest}`);
} catch (error) {
    console.error(error.message);
}
```