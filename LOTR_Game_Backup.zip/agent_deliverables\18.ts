```typescript
function isValidUrl(url: string): boolean {
    const pattern =^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+(?:[\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?$/i;
    return pattern.test(url);
}

// Example usage:
console.log(isValidUrl("https://www.example.com"));  // true
console.log(isValidUrl("invalid url"));  // false
```