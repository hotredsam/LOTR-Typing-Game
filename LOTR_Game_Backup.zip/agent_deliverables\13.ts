```typescript
function findSecondLargest(nums: number[]): number | null {
    if (nums.length < 2) return null;

    const maxNum = Math.max(...nums);
    const filteredNums = nums.filter(num => num !== maxNum);

    return filteredNums.length > 0 ? Math.max(...filteredNums) : null;
}

// Example usage:
const numbers = [10, 20, 30, 40, 50];
console.log(findSecondLargest(numbers)); // Output: 40
```