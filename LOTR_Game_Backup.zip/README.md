# Fantasy Typing Game

A multi-agent developed typing game set in a fantasy world.

## Project Structure
- `docs/`: Project documentation
- `src/`: Source code
- `assets/`: Game assets
- `tasks/`: Task queue for agents
- `logs/`: Project and agent logs

## Getting Started
1. Install dependencies: `npm install`
2. Run development server: `npm run dev`
