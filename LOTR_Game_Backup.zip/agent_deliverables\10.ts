```typescript
function areAnagrams(str1: string, str2: string): boolean {
    // Remove any white spaces and convert to lower case
    str1 = str1.replace(/\s/g, '').toLowerCase();
    str2 = str2.replace(/\s/g, '').toLowerCase();

    // Check if sorted versions of both strings are equal
    return [...str1].sort().join('') === [...str2].sort().join('');
}

// Example usage:
console.log(areAnagrams('Listen', 'Silent'));  // Returns: true
console.log(areAnagrams('Hello', 'World'));  // Returns: false
```