```typescript
function isValidEmail(email: string): boolean {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
}

// Example usage:
console.log(isValidEmail("test@example.com"));  // true
console.log(isValidEmail("invalid_email"));  // false
```