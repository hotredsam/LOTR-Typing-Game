# agent_worker.ps1 - Local Agent Task Runner
$queuePath = "tasks/queue.json"
$statusPath = "logs/agent_status.json"
$errorPath = "logs/agent_errors.json"
$ollamaUrl = "http://localhost:11434/api/generate"

function Log-Error($taskId, $errorMsg) {
    $errorLog = @{
        timestamp = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
        taskId = $taskId
        error = $errorMsg
    }
    $logs = if (Test-Path $errorPath) { Get-Content $errorPath | ConvertFrom-Json } else { @() }
    $logs += $errorLog
    $logs | ConvertTo-Json -Depth 10 | Set-Content $errorPath
}

while ($true) {
    if (-not (Test-Path $queuePath)) { Start-Sleep -Seconds 10; continue }
    
    $queue = Get-Content $queuePath | ConvertFrom-Json
    $pendingTask = $queue.tasks | Where-Object { $_.status -eq "pending" } | Select-Object -First 1
    
    if ($null -eq $pendingTask) {
        Write-Host "No pending tasks. Waiting..."
        Start-Sleep -Seconds 30
        continue
    }
    
    Write-Host "Processing Task: $($pendingTask.id)"
    $pendingTask.status = "in_progress"
    $queue | ConvertTo-Json -Depth 10 | Set-Content $queuePath
    
    try {
        $body = @{
            model = "llama3.1:8b"
            prompt = $pendingTask.prompt
            stream = $false
        } | ConvertTo-Json
        
        $response = Invoke-RestMethod -Uri $ollamaUrl -Method Post -Body $body -ContentType "application/json"
        
        $outputPath = $pendingTask.output_path
        $dir = [System.IO.Path]::GetDirectoryName($outputPath)
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force }
        
        $response.response | Set-Content $outputPath
        
        # Update the task in the queue object directly
        $taskInQueue = $queue.tasks | Where-Object { $_.id -eq $pendingTask.id }
        $taskInQueue.status = "completed"
        $taskInQueue | Add-Member -MemberType NoteProperty -Name "completed_at" -Value (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ") -Force
    } catch {
        $taskInQueue = $queue.tasks | Where-Object { $_.id -eq $pendingTask.id }
        $taskInQueue.status = "failed"
        Log-Error $pendingTask.id $_.Exception.Message
    }
    
    $queue | ConvertTo-Json -Depth 10 | Set-Content $queuePath
    Start-Sleep -Seconds 2
}
