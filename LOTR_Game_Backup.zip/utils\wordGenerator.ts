/**
 * Fantasy word generator for the typing game.
 */

const fantasyTerms = [
  'dragon', 'wizard', 'castle', 'sword', 'shield', 
  'horse', 'unicorn', 'elf', 'dwarf', 'magic', 
  'spell', 'curse', 'enchanted', 'fairytale', 'legend', 
  'mythical', 'treasure', 'adventure', 'quest', 'hero',
  'dungeon', 'goblin', 'orc', 'paladin', 'ranger'
];

/**
 * Returns a random fantasy term.
 */
export function getRandomWord(): string {
  return fantasyTerms[Math.floor(Math.random() * fantasyTerms.length)];
}
