import Phaser from 'phaser';
import { useGameStore } from '../stores/useGameStore';
import { getRandomWord } from '../utils/wordGenerator';
import { InputHandler } from './InputHandler';
import { IWord } from '../types/game';
import { calculateStats } from '../utils/scoring';
import { getDifficulty } from '../utils/difficultyManager';

export default class MainScene extends Phaser.Scene {
  private inputHandler!: InputHandler;
  private wordObjects: Map<string, Phaser.GameObjects.Text> = new Map();
  private spawnTimer!: Phaser.Time.TimerEvent;
  
  private startTime: number = 0;
  private totalCharsTyped: number = 0;
  private correctCharsTyped: number = 0;

  constructor() {
    super('MainScene');
  }

  create(): void {
    const { width, height } = this.scale;
    this.startTime = Date.now();
    this.totalCharsTyped = 0;
    this.correctCharsTyped = 0;

    // Background
    const graphics = this.make.graphics({ x: 0, y: 0 });
    graphics.fillStyle(0x1a1a2e, 1);
    graphics.fillRect(0, 0, width, height);
    graphics.generateTexture('game_bg', width, height);
    
    // Particle texture
    graphics.clear();
    graphics.fillStyle(0xffffff, 1);
    graphics.fillRect(0, 0, 4, 4);
    graphics.generateTexture('particle', 4, 4);
    
    this.add.image(0, 0, 'game_bg').setOrigin(0, 0);
    graphics.destroy();

    // Initialize Input
    this.inputHandler = new InputHandler((char) => this.handleKeyPress(char));

    // Initial Spawning Timer
    const difficulty = getDifficulty(0);
    this.spawnTimer = this.time.addEvent({
      delay: difficulty.spawnRate,
      callback: this.spawnWord,
      callbackScope: this,
      loop: true
    });

    this.events.on('shutdown', () => {
      this.inputHandler.cleanup();
      this.spawnTimer.destroy();
    });
  }

  private spawnWord(): void {
    const { score } = useGameStore.getState();
    const difficulty = getDifficulty(score);

    // Update timer if difficulty changed
    if (this.spawnTimer.delay !== difficulty.spawnRate) {
      this.spawnTimer.reset({
        delay: difficulty.spawnRate,
        callback: this.spawnWord,
        callbackScope: this,
        loop: true
      });
    }

    const wordText = getRandomWord();
    const id = Phaser.Utils.String.UUID();
    const x = Phaser.Math.Between(100, 700);
    const speed = Phaser.Math.Between(difficulty.minSpeed, difficulty.maxSpeed);

    const wordData: IWord = { id, text: wordText, x, y: -50, speed };
    useGameStore.getState().addWord(wordData);

    const textObj = this.add.text(x, -50, wordText, {
      fontSize: '28px',
      color: '#ffffff',
      fontFamily: 'Cinzel, serif',
      backgroundColor: '#00000088',
      padding: { x: 8, y: 8 }
    }).setOrigin(0.5);

    this.wordObjects.set(id, textObj);
  }

  private handleKeyPress(char: string): void {
    const { activeWords, updateScore, setStats, isGameOver } = useGameStore.getState();
    if (isGameOver) return;

    this.totalCharsTyped++;
    
    // Find a word that starts with this char
    const matchedWord = activeWords.find(w => w.text.toLowerCase().startsWith(char.toLowerCase()));
    
    if (matchedWord) {
      this.correctCharsTyped += matchedWord.text.length;
      updateScore(matchedWord.text.length * 10);
      
      const textObj = this.wordObjects.get(matchedWord.id);
      if (textObj) {
        // Particles
        const emitter = this.add.particles(textObj.x, textObj.y, 'particle', {
          speed: { min: 50, max: 150 },
          scale: { start: 1, end: 0 },
          blendMode: 'ADD',
          lifespan: 500,
          tint: 0xffd700,
          gravityY: 200,
          quantity: 20,
          emitting: false
        });
        emitter.explode(20);
        this.time.delayedCall(1000, () => emitter.destroy());

        this.removeWord(matchedWord.id);
        
        this.tweens.add({
          targets: textObj,
          alpha: 0,
          scale: 2,
          y: textObj.y - 50,
          duration: 300,
          onComplete: () => textObj.destroy()
        });
      }
    }

    // Update WPM/Accuracy in store
    const stats = calculateStats(this.totalCharsTyped, this.correctCharsTyped, this.startTime, Date.now());
    setStats(stats.wpm, stats.accuracy);
  }

  private removeWord(id: string): void {
    useGameStore.getState().removeWord(id);
    const textObj = this.wordObjects.get(id);
    if (textObj) {
      textObj.destroy();
      this.wordObjects.delete(id);
    }
  }

  update(time: number, delta: number): void {
    const { activeWords, setGameOver, isGameOver } = useGameStore.getState();
    if (isGameOver) return;

    const dt = delta / 1000;

    activeWords.forEach(word => {
      const textObj = this.wordObjects.get(word.id);
      if (textObj) {
        word.y += word.speed * dt;
        textObj.setPosition(word.x, word.y);

        if (word.y > 600) {
          setGameOver(true);
        }
      }
    });
  }
}
