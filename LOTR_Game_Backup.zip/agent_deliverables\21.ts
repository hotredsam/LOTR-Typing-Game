```typescript
function longestCommonSubstring(str1: string, str2: string): string {
    const m = str1.length;
    const n = str2.length;

    // Create a 2D array to store lengths of longest common substrings
    const dp: number[][] = Array(m + 1).fill(0).map(() => Array(n + 1).fill(0));

    let maxLength = 0;
    let end = 0;

    for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
            if (str1[i - 1] === str2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1] + 1;
                if (dp[i][j] > maxLength) {
                    maxLength = dp[i][j];
                    end = i;
                }
            } else {
                dp[i][j] = 0;
            }
        }
    }

    return str1.substring(end - maxLength, end);
}

// Test the function
const str1 = "abcdef";
const str2 = "zbcdfg";
console.log("Longest common substring is:", longestCommonSubstring(str1, str2));
```