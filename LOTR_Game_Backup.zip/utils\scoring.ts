/**
 * Calculates the stats of a typing session.
 *
 * @param typedChars The total number of characters typed.
 * @param correctChars The number of correctly typed characters.
 * @param startTime The start time of the typing session in milliseconds.
 * @param endTime The end time of the typing session in milliseconds.
 * @returns An object with the calculated WPM, accuracy and raw WPM.
 */
export function calculateStats(
  typedChars: number,
  correctChars: number,
  startTime: number,
  endTime: number
): { wpm: number, accuracy: number, rawWpm: number } {
  const timeDiff = endTime - startTime;

  if (timeDiff === 0) {
    return {
      wpm: 0,
      accuracy: 0,
      rawWpm: 0,
    };
  }

  const wpm = (correctChars / 5) / (timeDiff / 60000);
  const accuracy = typedChars === 0 ? 0 : (correctChars / typedChars) * 100;
  const rawWpm = (typedChars / 5) / (timeDiff / 60000);

  return { wpm, accuracy, rawWpm };
}
