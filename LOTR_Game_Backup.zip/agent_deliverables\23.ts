```typescript
class Node {
    data: number;
    next: Node | null;

    constructor(data: number) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    head: Node | null;

    constructor() {
        this.head = null;
    }

    append(data: number): void {
        const newNode = new Node(data);
        if (!this.head) {
            this.head = newNode;
            return;
        }
        let current = this.head;
        while (current.next) {
            current = current.next;
        }
        current.next = newNode;
    }

    reverse(): void {
        let prev: Node | null = null;
        let current = this.head;
        while (current) {
            const nextNode = current.next;
            current.next = prev;
            prev = current;
            current = nextNode;
        }
        this.head = prev;
    }

    printList(): void {
        let current = this.head;
        while (current) {
            process.stdout.write(current.data + ' ');
            current = current.next;
        }
        console.log();
    }
}

// Test the program
const ll = new LinkedList();
ll.append(1);
ll.append(2);
ll.append(3);
ll.append(4);

console.log("Original List:");
ll.printList();

ll.reverse();

console.log("Reversed List:");
ll.printList();
```