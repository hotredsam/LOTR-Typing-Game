```typescript
function fibonacci(n: number): number {
    if (n <= 0) {
        throw new Error("Input should be a positive integer.");
    } else if (n === 1) {
        return 0;
    } else if (n === 2) {
        return 1;
    }

    let fibNMinusTwo = 0;
    let fibNMinusOne = 1;

    for (let i = 3; i <= n; i++) {
        const fibN = fibNMinusOne + fibNMinusTwo;
        fibNMinusTwo = fibNMinusOne;
        fibNMinusOne = fibN;
    }

    return fibN;
}

// Example usage:
console.log(fibonacci(10));  // Output: 55
```