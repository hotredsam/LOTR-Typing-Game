```typescript
class Stack {
    private items: any[];

    constructor() {
        this.items = [];
    }

    // Push an element onto the stack
    public push(item: any): void {
        this.items.push(item);
    }

    // Pop an element from the stack
    public pop(): any {
        if (this.isEmpty()) {
            throw new Error("Stack is empty");
        }
        return this.items.pop();
    }

    // Get the top element of the stack without removing it
    public peek(): any {
        if (this.isEmpty()) {
            throw new Error("Stack is empty");
        }
        return this.items[this.items.length - 1];
    }

    // Check if the stack is empty
    public isEmpty(): boolean {
        return this.items.length === 0;
    }

    // Get the size of the stack
    public size(): number {
        return this.items.length;
    }

    // Clear the stack
    public clear(): void {
        this.items = [];
    }
}

// Example usage:
const stack = new Stack();
stack.push(1);
stack.push(2);
stack.push(3);

console.log(stack.peek());  // Output: 3
console.log(stack.pop());   // Output: 3
console.log(stack.size());  // Output: 2

stack.clear();
console.log(stack.isEmpty());  // Output: true
```