```typescript
function isPalindrome(s: string): boolean {
    s = s.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    return s === s.split('').reverse().join('');
}

// Example usage:
console.log(isPalindrome('A man, a plan, a canal: Panama')); // true
console.log(isPalindrome('Not a palindrome')); // false
```