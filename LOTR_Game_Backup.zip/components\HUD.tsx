import React from 'react';
import { useGameStore } from '../stores/useGameStore';

const HUD: React.FC = () => {
  const score = useGameStore((state) => state.score);
  const wpm = useGameStore((state) => state.wpm);
  const accuracy = useGameStore((state) => state.accuracy);
  const level = useGameStore((state) => state.level);

  const containerStyle: React.CSSProperties = {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    display: 'flex',
    justifyContent: 'space-around',
    padding: '10px 0',
    background: 'linear-gradient(to bottom, rgba(0,0,0,0.8), rgba(0,0,0,0))',
    color: '#ffd700', // Gold
    fontFamily: "'Cinzel', serif",
    fontSize: '20px',
    pointerEvents: 'none',
    textShadow: '2px 2px 4px #000'
  };

  return (
    <div style={containerStyle}>
      <div>SCORE: {score}</div>
      <div>WPM: {Math.round(wpm)}</div>
      <div>ACCURACY: {Math.round(accuracy)}%</div>
      <div>LEVEL: {level}</div>
    </div>
  );
};

export default HUD;
