# gemini_callback.ps1 - Request Orchestrator Review
$statusPath = "logs/agent_status.json"
if (Test-Path $statusPath) {
    $status = Get-Content $statusPath | ConvertFrom-Json
    $status.callback_requested = $true
    $status.last_updated = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
    $status | ConvertTo-Json -Depth 10 | Set-Content $statusPath
    Write-Host "Callback requested for Gemini Orchestrator."
}
