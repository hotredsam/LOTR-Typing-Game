```typescript
class Calculator {
    private readonly operations: { [key: string]: (a: number, b: number) => number };

    constructor() {
        this.operations = {
            '+': (a, b) => a + b,
            '-': (a, b) => a - b,
            '*': (a, b) => a * b,
            '/': (a, b) => a / b
        };
    }

    public calculate(operation: string, num1: number, num2: number): number {
        if (!(operation in this.operations)) {
            throw new Error(`Invalid operation. Supported operations are: +, -, *, /`);
        }
        return this.operations[operation](num1, num2);
    }
}

// Example usage:
const calculator = new Calculator();
console.log(calculator.calculate('+', 10, 5)); // Output: 15
console.log(calculator.calculate('-', 10, 5)); // Output: 5
console.log(calculator.calculate('*', 10, 5)); // Output: 50
console.log(calculator.calculate('/', 10, 5)); // Output: 2
```