```typescript
class TodoList {
  private tasks: { id: number; description: string }[];

  constructor() {
    this.tasks = [];
  }

  addTask(description: string): void {
    const newTaskId = this.tasks.length + 1;
    this.tasks.push({ id: newTaskId, description });
    console.log(`Task added with ID ${newTaskId}`);
  }

  deleteTask(id: number): void {
    const index = this.tasks.findIndex((task) => task.id === id);
    if (index !== -1) {
      this.tasks.splice(index, 1);
      console.log(`Task with ID ${id} deleted`);
    } else {
      console.log(`No task found with ID ${id}`);
    }
  }

  listTasks(): void {
    if (this.tasks.length === 0) {
      console.log("No tasks available");
    } else {
      this.tasks.forEach((task, index) => {
        console.log(`${index + 1}. ${task.description} - ID: ${task.id}`);
      });
    }
  }

  updateTask(id: number, description: string): void {
    const index = this.tasks.findIndex((task) => task.id === id);
    if (index !== -1) {
      this.tasks[index].description = description;
      console.log(`Task with ID ${id} updated`);
    } else {
      console.log(`No task found with ID ${id}`);
    }
  }
}

// Example usage
const todoList = new TodoList();

while (true) {
  console.log("\n1. Add Task");
  console.log("2. Delete Task");
  console.log("3. List Tasks");
  console.log("4. Update Task");
  console.log("5. Exit");

  const choice = prompt("Choose an option: ");

  switch (choice) {
    case "1":
      const description = prompt("Enter task description: ");
      todoList.addTask(description);
      break;
    case "2":
      const idToDelete = parseInt(prompt("Enter task ID to delete: "));
      todoList.deleteTask(idToDelete);
      break;
    case "3":
      todoList.listTasks();
      break;
    case "4":
      const idToUpdate = parseInt(prompt("Enter task ID to update: "));
      const newDescription = prompt("Enter new task description: ");
      todoList.updateTask(idToUpdate, newDescription);
      break;
    case "5":
      console.log("Exiting...");
      return;
    default:
      console.log("Invalid option. Please choose a valid option.");
  }
}
```