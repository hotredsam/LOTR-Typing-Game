```typescript
function fibonacci(n: number): number {
    const fib: number[] = new Array(n + 1).fill(0);
    fib[1] = 1;

    for (let i = 2; i <= n; i++) {
        fib[i] = fib[i - 1] + fib[i - 2];
    }

    return fib[n];
}

// Example usage:
console.log(fibonacci(10)); // Output: 55
```